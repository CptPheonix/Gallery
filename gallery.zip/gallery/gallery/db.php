<?php
// Start user session
session_start();
$con = mysqli_connect("localhost","root","Admin","gallery");
?>

<?php if (mysqli_connect_errno()): ?>
<div class="alert alert-primary" role="alert">
  Failed to connect to the database: <?= mysqli_connect_error();  ?>
</div>
<?php endif; ?>