<?php include_once 'db.php';

if(isset($_SESSION['logged-in'])) {
    $message = 'Welcome admin';
} else {
    header("location: index.php");
}

if(isset($_POST['add-post'])) {

    $name = $_POST['name'];
    $post = $_POST['post'];
    $image = $_FILES['image']['name'];

    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["image"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
    // Check if image file is a actual image or fake image
    if(isset($_POST["submit"])) {
        $check = getimagesize($_FILES["image"]["tmp_name"]);
        if($check !== false) {
            echo "File is an image - " . $check["mime"] . ".";
            $uploadOk = 1;
        } else {
            echo "File is not an image.";
            $uploadOk = 0;
        }
    }

    // Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) {
        echo "Sorry, your file was not uploaded.";
    // if everything is ok, try to upload file
    } else {
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
            echo "The file ". basename( $_FILES["image"]["name"]). " has been uploaded.";
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    }

    $sql = "INSERT INTO posts (name, post, image, date) VALUES ('$name', '$post', '$image', CURRENT_TIMESTAMP)";

    if ( $con->query($sql) ){
        echo 'Post added';
    }

    else {
        echo 'Failure to add post';
    }

}

if(isset($_POST['add-user'])) {

    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "INSERT INTO users (username, password, date) VALUES ('$username', '$password', CURRENT_TIMESTAMP)";

    if ( $con->query($sql) ){
        echo 'User added';
    }

    else {
        echo 'Failure to add user';
    }

}

?>

<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">

    <title>Gallery Catalog</title>
</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="#">Gallery</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
            aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="posts.php">Gallery</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="admin.php">Admin</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">Log Out</a>
                </li>
            </ul>
        </div>
    </nav>

    <h1 class="text-center"><?php echo $message; ?></h1>

    <!-- Add Post -->
    <div class="jumbotron text-center">
        <hr>
        <h2>Add Post</h2>
        <div class="container">
            <form method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <p>Title</p>
                    <input type="text" class="form-control" name="name" placeholder="Title">
                </div>
                <div class="form-group">
                    <p>Image</p>
                    <input type="file" name="image">                
                </div>
                <div class="form-group">
                    <p>Post</p>
                    <textarea type="text" class="form-control" name="post" placeholder="post" rows="3"></textarea>
                </div>
                <button class="btn btn-primary" name="add-post" type="submit">Add Post</button>
            </form>
        </div>
    </div>

    <!-- Add User -->
    <div class="jumbotron text-center">
        <hr>
        <h2>Add User</h2>
        <div class="container">
            <form method="post">
                <div class="form-group">
                    <p>Username</p>
                    <input type="text" class="form-control" name="username" placeholder="Username">
                </div>
                <div class="form-group">
                    <p>Password</p>
                    <input type="password" class="form-control" name="password" placeholder="Password">
                </div>
                <button class="btn btn-primary" name="add-user">Add Post</button>
            </form>
        </div>
    </div>


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
        crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
        crossorigin="anonymous"></script>
</body>

</html>