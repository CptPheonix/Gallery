<?php include_once 'db.php';

unset($_SESSION['logged-in']);

header("location: index.php");

?>